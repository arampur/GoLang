package main

import (
	"database/sql"
	"encoding/json"
	"html/template"
	"log"
	"net/http"

	_ "github.com/lib/pq"
)

const (
	host     = "localhost"
	port     = "5432"
	user     = "postgres"
	password = "3638"
	dbname   = "TravelPlanner"
)

var db *sql.DB

func init() {
	var err error
	connStr := "user=" + user + " password=" + password + " dbname=" + dbname + " sslmode=disable"
	db, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal(err)
	}

	err = db.Ping()
	if err != nil {
		log.Fatal(err)
	}
}

func main() {
	http.HandleFunc("/", indexHandler)
	http.ListenAndServe(":9000", nil)
}

func indexHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		cityName := r.FormValue("cityName")
		if cityName != "" {
			cities, err := fetchCities(cityName)
			if err != nil {
				http.Error(w, "Error fetching cities from the database", http.StatusInternalServerError)
				return
			}

			citiesJSON, _ := json.Marshal(cities)
			w.Header().Set("Content-Type", "application/json")
			w.Write(citiesJSON)
			return
		}
	}

	renderTemplate(w)
}

func fetchCities(prefix string) ([]string, error) {
	rows, err := db.Query("SELECT name FROM cities WHERE country_code = 'US' AND name ILIKE $1 LIMIT 10", prefix+"%")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var cities []string
	for rows.Next() {
		var cityName string
		if err := rows.Scan(&cityName); err != nil {
			return nil, err
		}
		cities = append(cities, cityName)
	}

	return cities, nil
}

func renderTemplate(w http.ResponseWriter) {
	tmpl, err := template.New("index").Parse(`
		<!DOCTYPE html>
		<html>
		<head>
			<title>City Autocomplete</title>
			<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
			<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
			<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		</head>
		<body>
			<h1>City Autocomplete</h1>
			<form method="post" action="/">
				<label for="cityName">Enter City Name:</label>
				<input type="text" id="cityName" name="cityName" autocomplete="off">
			</form>
			<div id="cityList"></div>

			<script>
				$(function () {
					$("#cityName").autocomplete({
						source: function (request, response) {
							$.ajax({
								url: "/",
								type: "POST",
								data: { cityName: request.term },
								success: function (data) {
									response(data);
								}
							});
						},
						minLength: 2,
						select: function (event, ui) {
							console.log(ui.item.value);
						}
					});
				});
			</script>
		</body>
		</html>
	`)
	if err != nil {
		http.Error(w, "Error rendering template", http.StatusInternalServerError)
		return
	}

	if err := tmpl.Execute(w, nil); err != nil {
		http.Error(w, "Error executing template", http.StatusInternalServerError)
		return
	}
}
